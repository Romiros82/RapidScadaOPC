OPC сервер подключается к серверу RapidScada по TCP и может быть установлен как локально, так и на другой машине (если сервер RapidScada работает на Linux или для избежания проблем с DCOM).
Сервер позволяет клиентам читать данные входных каналов с заданным периодом опроса, производить запись во входные каналы и каналы управления.
Для установки сервера следуйте следующей инструкции:
1. Установите .NET Framework
Установите .NET Framework 4.7.2 загрузив его с www.microsoft.com.  

2. Установите Visual C++ Redistributable для Visual Studio 2017
Исполняемый файл сервера OpcNetDaServer.exe разработан на C++ и Visual Studio 2017, поэтому Вам необходимо установить Visual C++ Redistributable for Visual Studio 2017. Используйте одну из следующих ссылок: 
https://go.microsoft.com/fwlink/?LinkId=746572 - для 64bit версии Windows.
https://go.microsoft.com/fwlink/?LinkId=746571 - для 32bit версии Windows.

3. OPC Core Components distributable
Установите OPC Core components загрузи их по одной из следующих ссылок:  
https://rapidscada.ru/download/OPC%20Core%20Components%20Redistributable%20(x64)%20105.1.zip - для 64bit версии Windows.
https://rapidscada.ru/download/OPC%20Core%20Components%20Redistributable%20(x86)%20105.1.zip - для 32bit версии Windows.

4. Скопируйте все файлы из папки "ScadaServer" в папку с установленной RapidScada, по умолчанию C:\SCADA, с сохранением иерархии.
Откройте ScadaServer\Config\OPCServerConfig.xml, при необходимости внесите изменения и сохраните файл.
Если необходимо установить сервер на другой компьютер, скопируйте папку "ScadaServer" на другую машину с сохранением иерархии.
Можно переименовать папку "ScadaServer" при необходимости. Скопируйте в эту папку файлы ScadaData.dll и Log.dll из папки RapidScada.

5. Регистрация/Разрегистрация  OPC сервера
Регистрация
Выполните следующую команду для регистрации OPC сервера:  OpcNetDaServer.exe -regserver 
Регистрация в качестве службы
Выполните следующую команду для регистрации OPC сервера в качестве службы: OpcNetDaServer.exe -service 
Разрегистрация
Вы можете отменить регистрацию OPC сервера выполнив следующую команду: OpcNetDaAeServer.exe -unregserver 

6. Запустите Ваш OPC клиент и подключитесь к OPC серверу.