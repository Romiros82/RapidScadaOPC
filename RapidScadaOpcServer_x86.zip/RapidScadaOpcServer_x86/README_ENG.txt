
1. Install the .NET Framework
Install the .NET Framework 4.7.2 distributable which can be downloaded from www.microsoft.com.

2. Install the Visual C++ Redistributable for Visual Studio 2017
The generic server executables OpcNetDaServer.exe are developed with C++ and Visual Studio 2017. Because of this you need to install the Visual C++ Redistributable for Visual Studio 2017. Use one of the following: 
https://go.microsoft.com/fwlink/?LinkId=746572
If the operating system used is a 64bit operating system and the used generic server executable is 64bit you need to use this redistributables. 
https://go.microsoft.com/fwlink/?LinkId=746571
If the operating system used is a 32bit operating system or the used generic server executable is 32bit you need to use this redistributables.

3. OPC Core Components distributable
This setup application installs the OPC Core components required by applications based on the OPC DA/AE Server SDK .NET. Use one of the following:
https://rapidscada.org/download/OPC%20Core%20Components%20Redistributable%20(x64)%20105.1.zip
If the operating system used is a 64bit operating system you need to use this OPC Core Components. 
https://rapidscada.org/download/OPC%20Core%20Components%20Redistributable%20(x86)%20105.1.zip
If the operating system used is a 32bit operating system you need to use this OPC Core Components.
 
4. Copy all files from the folder "ScadaServer" to the Rapid SCADA installation directory, the default is C:\SCADA, with the hierarchy of directories retained.
Open ScadaServer\Config\OPCServerConfig.xml, change connection parameters if neded and save file.
If you want install OPC Server to anothe mashin, copy folder "ScadaServer" to computer with the hierarchy of directories retained. Rename folder "ScadaServer" if neded, and copy to this folder ScadaData.dll and Log.dll from RapidScada folder.

5. Register/Unregister the OPC Server
Register
You can use the following command to register the OPC Server:  OpcNetDaServer.exe -regserver 
Register as Service
You can use the following command to register the OPC Server as service: OpcNetDaServer.exe -service 
Unregister
You can use the following command to unregister the OPC Server: OpcNetDaAeServer.exe -unregserver 
In the DCOM OPC server name as "RapidScada OPC DA Server V5.0"

6. Run you OPC Client and connect to the server.